import java.util.ArrayList;

public class GiftCard {
    private int cardNo;
    private int cardPin;
    private double GiftCardBalance;
    private int rewardPoints;
    ArrayList<Transaction> transactions=new ArrayList<>();

    public GiftCard(int cardNo, int cardPin, double giftCardBalance,int rewardPoints) {
        this.cardNo = cardNo;
        this.cardPin = cardPin;
        this.GiftCardBalance = giftCardBalance;
        this.rewardPoints=0;
    }

    public int getCardNo() {
        return cardNo;
    }

    public void setCardNo(int cardNo) {
        this.cardNo = cardNo;
    }

    public int getCardPin() {
        return cardPin;
    }

    public int getRewardPoints() {
        return rewardPoints;
    }

    public void setCardPin(int cardPin) {
        this.cardPin = cardPin;
    }

    public double getGiftCardBalance() {
        return GiftCardBalance;
    }

    public void setGiftCardBalance(int giftCardBalance) {
        GiftCardBalance = giftCardBalance;
    }

    public void addGiftCardBalance(double amount)
    {
        GiftCardBalance+=amount;
        Transaction t=new Transaction();
        t.setCredit(amount);
        t.setBalance(this.GiftCardBalance);
        transactions.add(t);

    }
    public void deductGiftCardBalance(double amount)
    {
        this.GiftCardBalance-=amount;
        Transaction t=new Transaction();
        this.rewardPoints+=amount/100;
        while(this.rewardPoints > 9){
            this.GiftCardBalance+= 10;
            this.rewardPoints -= 10;
        }

        t.setDebit(amount);
        t.setBalance(this.GiftCardBalance);
        transactions.add(t);
    }

    public ArrayList<Transaction> getTransactions() {
        return transactions;
    }

    /**
     * to display gift card details
     */
    public void displayGiftcardDetails()
    {
        /*
          to display
         */
        System.out.println("--GIFT CARD--");
        System.out.println("Card no: "+cardNo);
        System.out.println("Card pin: "+cardPin);
        System.out.println("Card balance: "+GiftCardBalance);
        System.out.println("Reward points: "+rewardPoints);
        System.out.println("----------------");
    }
}
