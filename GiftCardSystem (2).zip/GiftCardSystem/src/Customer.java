import java.util.HashMap;
import java.util.Scanner;

public class Customer {
    private int customerId;
    private int accNo;
    private String name;
    private double balance;
    private String encryptedPwd;
    private HashMap<Integer, GiftCard> Customergiftcards=new HashMap<>();
    Scanner sc = new Scanner(System.in);

    public Customer(int customerId, int accNo, String name, double balance, String encryptedPwd) {
        this.customerId = customerId;
        this.accNo = accNo;
        this.name = name;
        this.balance = balance;
        this.encryptedPwd = encryptedPwd;
    }

    public int getCustomerId() {
        return customerId;
    }

    public void setCustomerId(int customerId) {
        this.customerId = customerId;
    }

    public int getAccNo() {
        return accNo;
    }

    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public double getBalance() {
        return balance;
    }
    public void setBalance(double balance) {
        this.balance = balance;
    }
    public String getEncryptedPwd() {
        return encryptedPwd;
    }
    public void setEncryptedPwd(String encryptedPwd) {
        this.encryptedPwd = encryptedPwd;
    }
    public HashMap<Integer, GiftCard> getCustomergiftcards() {
        return Customergiftcards;
    }
    public void getCardNos()
    {
        System.out.println("List of available card numbers");int i=1;
        for(Integer cardno : Customergiftcards.keySet())
        {
            System.out.println(cardno);
        }
    }

    public void setCustomergiftcards(HashMap<Integer, GiftCard> customergiftcards) {
        Customergiftcards = customergiftcards;
    }

    public void addGiftcard(int cardid,GiftCard giftCard)
    {
        Customergiftcards.put(cardid,giftCard);
    }
    public void removeGiftcard(int cardid,GiftCard giftCard)
    {
        Customergiftcards.remove(cardid,giftCard);
    }
    public void addCustomerBalance(double amount){
        balance+=amount;
    }
    public void deductCustomerBalance(double amount)
    {
        balance-=amount;
    }

    public void displayAccountDetails()
    {
        System.out.println("---Account Details---");
        System.out.println("Customer name: "+this.getName());
        System.out.println("Account number: "+this.accNo);
        System.out.println("Customer id: "+this.customerId);
        System.out.println("Balance: "+this.balance);
        System.out.println("-----------------------");
    }

}
