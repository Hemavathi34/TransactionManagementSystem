import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class utility {
    public static boolean checkInput(String userInput)
    {
        String regx = "^[a-zA-Z\\s]*$";
        Pattern pattern = Pattern.compile(regx,Pattern.CASE_INSENSITIVE);
        Matcher matcher=pattern.matcher(userInput);
        return matcher.find();
    }
    public static boolean isValidPwd(String Password)
    {
        boolean isValid=true;
        if(Password.length()>20 || Password.length()<8)
        {
            //System.out.println("Password length should be more than 8 characters and less than 15 characters");
            isValid=false;
        }
        String uppercase="(.*[A-Z].*)";
        if(!Password.matches(uppercase))
        {
            //System.out.println("Password should contain atleast one uppercase character");
            isValid=false;
        }
        return isValid;
    }
    static String encryptPassword(String password)
    {
        String encryptPwd="";
        for(int i=0;i<password.length();i++)
        {
            char c=password.charAt(i);
            if(c>='A' && c<='Z')
            {
                char ch=(char)(((int)password.charAt(i)+1-65)%26 +65);
                encryptPwd+=ch;
            }
            if(c>='a' && c<='z')
            {
                char ch=(char)(((int)password.charAt(i)+1-97)%26+97);
                encryptPwd+=ch;
            }
            if(c>='0' && c<='9'){
                char ch=(char)(((int)password.charAt(i)+1-48)%10+48);
                encryptPwd+=ch;
            }
        }
        System.out.println(encryptPwd);
        return encryptPwd;
    }
}
