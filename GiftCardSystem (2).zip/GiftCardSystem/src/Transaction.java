public class Transaction {
    private double credit;
    private double debit;
    private double balance;

    public Transaction() {
        this.credit = 0;
        this.debit = 0;
        this.balance = 0;
    }


    public double getCredit() {
        return credit;
    }

    public void setCredit(double credit) {
        this.credit = credit;
    }

    public double getDebit() {
        return debit;
    }

    public void setDebit(double debit) {
        this.debit = debit;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    public void displayTransaction(){
        System.out.println("Credit: " + credit);
        System.out.println("Debit: " + debit);
        System.out.println("Balance: " + balance);
    }

/*    public void displaytransaction()
    {
        System.out.println("credit= "+credit+" debit= "+debit+" balance= "+balance);
    }*/
  @Override
    public String toString() {
        return "credit=" + credit +
                ", debit=" + debit +
                ", balance=" + balance;
    }
}
