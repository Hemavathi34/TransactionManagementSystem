import java.util.*;
public class Bank {
    public static void main(String[] args) {
        Bank b=new Bank();
        b.menu();
    }
    HashMap<Integer, Customer> customerList = new HashMap<>();
    HashMap<Integer, GiftCard> listOfGiftCards = new HashMap<>();
    int choice = 0;
    int customeridStart=11,accountnoStart=110110;
    int cardnoStart=10000,pinStart=1000;
    Scanner sc=new Scanner(System.in);
    public void menu(){
        Scanner sc = new Scanner(System.in);
        while(choice!=4)
        {
            System.out.println("---GIFT CARD SYSTEM---");
            System.out.println("1.Create an account");
            System.out.println("2.Account login");
            System.out.println("3.Purchase");
            System.out.println("4.Exit");
            while(!sc.hasNextInt())
            {
                System.out.println("Enter correctly");
                sc.next();
            }
            choice = sc.nextInt();
            switch (choice)
            {
                case 1:
                    createCustomer();
                    break;
                case 2:
                    login();
                    break;
                case 3:
                    purchase();
                    break;
                case 4:
                    break;
                default:
                    System.out.println("incorrect option");
                    menu();
            }
        }
    }
    int x=1;
    private void createCustomer()
    {

        String customerName=null;double customerBalance=0;
        System.out.println("Enter your name");
        sc.useDelimiter("\n");
        customerName = sc.next();int cnt=3;
        while(!utility.checkInput(customerName)){
            System.out.println("Enter your name correctly (should contain only alphabets)"+cnt+" chance(s) left");
            customerName=sc.next();
            cnt--;
            if(cnt==0)
            {
                return;
            }
        }
        System.out.println("Enter the bank balance");int cnt1=3;
        while (!sc.hasNextDouble() || customerBalance<0) {
            System.out.println("Enter your bank balance correctly (should contain only numbers) "+cnt1+" chances left");
            sc.next();
            cnt1--;
            if(cnt1==0)
            {
                return;
            }
        }
        customerBalance = sc.nextDouble();
        System.out.println("Enter the password");
        String customerPwd = sc.next();
        while(!utility.isValidPwd(customerPwd)){
            System.out.println("Password should contain 8-20 characters and an uppercase");
            customerPwd=sc.next();
        }
        String customerEncrptPwd = utility.encryptPassword(customerPwd);
        int customerId = customeridStart;
        int customerAccno = accountnoStart;
        Customer customer = new Customer(customerId, customerAccno, customerName, customerBalance, customerEncrptPwd);
        customerList.put(customerId, customer);
        System.out.println("Account created successfully!");
        customeridStart += 11;
        accountnoStart += 1000;
        System.out.println("Customer id: "+customer.getCustomerId());
        System.out.println("Account no: "+customer.getAccNo());
        System.out.println("Name: "+customer.getName());
        System.out.println("Balance: "+customer.getBalance());
        System.out.println("Password: "+customerPwd);

    }
    int cnt=3;boolean auth=false;
    private void login()
    {

        if(customerList.isEmpty()) {
            System.out.println("There are no accounts");
            return;
        }
        do {
            int custid;
            while(true) {
                try {
                    System.out.println("Enter the customer id: ");
/*            while (!sc.hasNextInt()) {
                System.out.println("Enter customer id correctly");
                sc.next();
            }*/
                    custid = sc.nextInt();
                    break;
                } catch (Exception e) {
                    System.out.println("invalid customer id (should contain only numbers)");
                    sc.next();
                }
            }

            System.out.println("Enter the password: ");
            String pwd = sc.next();
            String epwd = utility.encryptPassword(pwd);
            if (customerList.containsKey(custid)) {
                if (customerList.get(custid).getEncryptedPwd().equals((epwd))) {
                    System.out.println("Login successful!");
                    auth = true;
                    menu2(customerList.get(custid));
                } else {
                    System.out.println("incorrect login credentials! "+cnt+" chances left");
                    cnt--;
                }
            }
            else
            {
                System.out.println("incorrect login credentials! "+cnt+" chances left");
                cnt--;
            }
        }while(cnt>=0 && auth==false);

    }

    private void menu2(Customer customer)
    {

        customer.displayAccountDetails();
        int choice=0;
        while(choice!=5)
        {
            System.out.println("1. Create a new gift card");
            System.out.println("2. Top up the existing card");
            System.out.println("3. Show gift card transaction history");
            System.out.println("4. Block the existing card");
            System.out.println("5. Logout");
            while(!sc.hasNextInt())
            {
                System.out.println("Enter correctly");
                sc.next();
            }
            choice=sc.nextInt();
            switch(choice)
            {
                case 1:
                    createGiftcard(customer);
                    break;
                case 2:
                    topUpGiftcard(customer);
                    break;
                case 3:
                    transactionHistory(customer);
                    break;
                case 4:
                    blockGiftcard(customer);
                    break;
                case 5:
                    return;
                default:
                    System.out.println("incorrect option");

            }
        }

    }
    private void createGiftcard(Customer customer)
    {
        int cardId= cardnoStart;
        int pin=pinStart;
        double initialBal=0;
        int rewardpts=0;
        GiftCard giftCard=new GiftCard(cardId,pin,initialBal,rewardpts);
        listOfGiftCards.put(cardId,giftCard);
        customer.addGiftcard(cardId,giftCard);
        cardnoStart+=2;pinStart+=5;
        System.out.println("Gift card created! ");
        giftCard.displayGiftcardDetails();
    }

    private void topUpGiftcard(Customer customer)
    {

        if(customer.getCustomergiftcards().isEmpty())
        {
            System.out.println("There are no gift cards available to top up.");
            return;
        }
        customer.getCardNos();
        //System.out.println(customer.getCustomergiftcards());
        System.out.println("Enter the gift card number");
        while(!sc.hasNextInt()){
            System.out.println("Enter the card number correctly");
            sc.next();
        }
        int cardId= sc.nextInt();
        if(!customer.getCustomergiftcards().containsKey(cardId))
        {
            System.out.println("incorrect card no.");
            return;
        }
        System.out.println("Enter the amount");
        while (!sc.hasNextDouble()) {
            System.out.println("Enter the amount correctly");
            sc.next();
        }
        double amount= sc.nextDouble();
        while(amount<1 || amount>customer.getBalance())
        {
            System.out.println("enter the amount again");
            amount=sc.nextDouble();
            if(amount>customer.getBalance())
            {
                System.out.println("no enough money in your account so");
            }
            if(customer.getBalance()==0)
            {
                System.out.println("insufficient amount in your bank. Exiting..");
                return;
            }
        }
        /*while(amount>customer.getBalance())
        {
            System.out.println("Insufficient balance in your bank account");
            if(customer.getBalance()==0)
            {
                System.out.println("exiting..");
                return;
            }
            System.out.println("Enter the amount ");
            amount=sc.nextDouble();
        }*/
        customer.deductCustomerBalance(amount);
        GiftCard giftCard=customer.getCustomergiftcards().get(cardId);
        giftCard.addGiftCardBalance(amount);
        System.out.println("Top up successful!");
        System.out.println("giftcard balance: "+giftCard.getGiftCardBalance());

    }
    private void transactionHistory(Customer customer)
    {
        if(customer.getCustomergiftcards().isEmpty())
        {
            System.out.println("There are no gift cards available to view transaction history");
            return;
        }
        System.out.println("Enter gift card number");
        while(!sc.hasNextInt()){
            System.out.println("Enter the card number correctly");
            sc.next();
        }
        int cardno=sc.nextInt();
        System.out.println("Enter the pin ");
        int pin=sc.nextInt();
        if(customer.getCustomergiftcards().containsKey(cardno))
        {
            if(customer.getCustomergiftcards().get(cardno).getCardPin()==pin){
                GiftCard g=customer.getCustomergiftcards().get(cardno);
                System.out.println("--Transaction History--");
                ArrayList<Transaction> transactions=g.getTransactions();
                if(transactions.isEmpty())
                {
                    System.out.println("no transactions has been done yet.");
                    return;
                }
                int i=1;
                for(Transaction t: transactions )
                {
                    System.out.println("tid"+i+": "+t);
                    i++;
                }
            }
        }
        else
        {
            System.out.println("incorrect credentials.");
        }

    }
    private void blockGiftcard(Customer customer)
    {

        if(customer.getCustomergiftcards().isEmpty())
        {
            System.out.println("There are no gift cards available to block.");
            return;
        }
        customer.getCardNos();
        System.out.println("Enter the gift card number that you want to block");
        while(!sc.hasNextInt()){
            System.out.println("Enter the card number correctly");
            sc.next();
        }
        int cardno=sc.nextInt();
        if(!customer.getCustomergiftcards().containsKey(cardno))
        {
            System.out.println("no card found.");
            return;
        }
        GiftCard giftCard=customer.getCustomergiftcards().get(cardno);
        double amount=customer.getCustomergiftcards().get(cardno).getGiftCardBalance();
        customer.addCustomerBalance(amount);
        customer.removeGiftcard(cardno,giftCard);
        listOfGiftCards.remove(cardno,giftCard);
        System.out.println("Gift card is blocked!");

    }

    private void purchase()
    {

        if(listOfGiftCards.isEmpty())
        {
            System.out.println("No cards available");
            return;
        }
        System.out.println("Enter the card no");
        int cardno=sc.nextInt();
/*        while(!listOfGiftCards.containsKey(cardno))
        {
            System.out.println("incorrect card number enter again");
            cardno=sc.nextInt();
        }*/
        if(listOfGiftCards.containsKey(cardno)){
            System.out.println("Enter the pin");
            int pin=sc.nextInt();
            if(listOfGiftCards.get(cardno).getCardPin()==pin)
            {
                GiftCard giftCard=listOfGiftCards.get(cardno);
                System.out.println("Enter the amount");
                int amount=sc.nextInt();
                if(amount> giftCard.getGiftCardBalance())
                {
                    System.out.println("Insufficient balance in the giftcard");
                    return;
                }
                giftCard.deductGiftCardBalance(amount);
                System.out.println("Purchase successful!");
                System.out.println("Available balance: "+giftCard.getGiftCardBalance());
                System.out.println("Current reward points: "+giftCard.getRewardPoints());
            }
            else
            {
                System.out.println("Incorrect credentials!");
                return;
            }
        }
    }

}
